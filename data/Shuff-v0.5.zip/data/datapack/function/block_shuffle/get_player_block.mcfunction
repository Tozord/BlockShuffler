# Get player's assigned block from storage and check position
$data modify storage datapack:temp selected_block set from storage datapack:db players."$(UUID)".assigned_block

# Check if we have a block assigned
execute if data storage datapack:temp selected_block run function datapack:block_shuffle/check_block_match