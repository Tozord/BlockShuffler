# Check if player is standing on their assigned block
# Store the block below the player (gets the block ID)
data modify storage datapack:temp current_block_data set from block ~ ~-1 ~
data modify storage datapack:temp current_block set from storage datapack:temp current_block_data.Name

# Compare blocks directly (both have minecraft: prefix)
execute store success score #match bs.game_state run data modify storage datapack:temp selected_block set from storage datapack:temp current_block
execute if score #match bs.game_state matches 1 run function datapack:block_shuffle/player_found_block