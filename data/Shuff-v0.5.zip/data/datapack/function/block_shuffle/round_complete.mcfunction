# All players found their blocks - round complete!
tellraw @a {"text":"=== ROUND COMPLETE ===","color":"green","bold":true}
tellraw @a {"text":"All players found their blocks! Starting next round...","color":"yellow"}

# Check if there's only one player left (winner)
execute if entity @a[gamemode=!spectator] if entity @a[gamemode=!spectator,limit=2] run function datapack:block_shuffle/prepare_next_round
execute unless entity @a[gamemode=!spectator,limit=2] run function datapack:block_shuffle/game_winner 