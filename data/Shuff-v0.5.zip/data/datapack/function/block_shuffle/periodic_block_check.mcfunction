# Check if players are on their blocks
execute as @a[gamemode=!spectator,scores={bs.found_block=0}] run function datapack:block_shuffle/check_player_block