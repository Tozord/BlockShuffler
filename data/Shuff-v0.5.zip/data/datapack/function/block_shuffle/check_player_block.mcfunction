# Check if player is standing on their assigned block
# Use the same UUID method as the storage system
function datapack:block_shuffle/get_player_block with entity @s