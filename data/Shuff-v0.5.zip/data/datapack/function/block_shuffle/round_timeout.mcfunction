# Round timed out - eliminate players who didn't find their block
tellraw @a {"text":"=== TIME'S UP! ===","color":"red","bold":true}

# Eliminate players who didn't find their block
execute as @a[gamemode=!spectator,scores={bs.found_block=0}] run function datapack:block_shuffle/eliminate_player

# Check if game should continue
execute if entity @a[gamemode=!spectator,limit=2] run function datapack:block_shuffle/prepare_next_round
execute unless entity @a[gamemode=!spectator,limit=2] run function datapack:block_shuffle/game_winner 